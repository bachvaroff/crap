Miscellaneous complex math routines for 32bit XENIX (K&R C)
